import React from "react";

function Footer() {
  return (
    <footer>
      <p>Desenvolvido com ❤️ por Talia Moura, Nicoly Souza, Lorena Yasmin e Kevin Mukanda</p>
    </footer>
  );
}

export default Footer;
